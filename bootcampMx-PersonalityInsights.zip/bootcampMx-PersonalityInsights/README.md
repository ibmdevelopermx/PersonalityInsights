# bootcampMx-PersonalityInsights
Aplicación que simula una herramienta para contratar a los mejores prospectos con base en un análisis de su personalidad. Utiliza el servicio de Watson Personality Insights.
